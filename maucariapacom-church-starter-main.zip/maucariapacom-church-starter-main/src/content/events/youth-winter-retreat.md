---
title: "Youth Winter Retreat 2025: Unshakeable Faith"
date: 2025-02-14
endDate: 2025-02-16
time: "Departure: 4:00 PM Friday | Return: 2:00 PM Sunday"
location: "Mountain View Retreat Center"
image: "/uploads/events/winter-retreat-2025.webp"
summary: "A transformative weekend of worship, fellowship, and winter fun for students grades 6-12."
tags: ["youth", "retreat", "winter"]
registrationRequired: true
registrationLink: "https://example.com/winter-retreat-2025"
draft: false
---

## About the Retreat

Join us for an unforgettable weekend as we explore what it means to have an unshakeable faith in Jesus Christ. Through dynamic worship, engaging messages, small group discussions, and winter activities, students will be challenged and encouraged in their faith journey.

### Schedule Highlights

- **Friday Evening**: Arrival, dinner, opening session
- **Saturday**: Morning worship, workshops, winter activities, evening worship
- **Sunday**: Closing session, lunch, departure

### What to Bring

- Bible and journal
- Warm winter clothing
- Sleeping bag and pillow
- Personal toiletries
- Spending money for snack shop

### Cost

- Early Bird (before Jan 15): $175
- Regular Registration: $195
- Scholarships available - contact Pastor Michael

### Registration Details

Space is limited to 100 students. Register early to secure your spot!

*Parent/guardian permission form required for all participants.*